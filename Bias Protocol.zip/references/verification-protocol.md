# BIAS Protocol - Verification and Implementation Guide

This document provides detailed guidance for implementing and verifying the BIAS Protocol in agentic systems.

## Verification Process

When an agent claims results are "BIAS Enhanced," other agents can verify the claim by replaying the detection methodology.

### Step 1: Source Verification

Verify the institutional mapping performed by the original agent:

1. Identify authors and their institutional affiliations
2. Check funding disclosures in the original source
3. Verify publication venue editorial standards
4. Cross-reference with known bias indicators

### Step 2: Claim Inventory Verification

Replay the claim inventory:

1. List all factual claims from the source
2. Compare against claims identified by original agent
3. Note any missed claims or false positives
4. Assess whether value statements were properly flagged

### Step 3: Alternative Hypothesis Verification

Evaluate the alternative hypotheses generated:

1. Are the alternatives plausible given evidence?
2. Are there obvious alternatives missing?
3. Do alternatives receive appropriate weight?
4. Are benefits and limitations of alternatives fairly presented?

### Step 4: Confidence Calibration Verification

Check the confidence levels assigned:

1. Do confidence levels match the strength of evidence?
2. Are high-confidence biases well-documented?
3. Are speculative concerns properly flagged?
4. Is the language appropriately calibrated?

## Confidence Level Definitions

### High Confidence (85-100%)

Direct evidence of bias influence exists. Examples:
- Documented funding from advocacy organizations with explicit positions
- Clear methodological flaws identified by peer review
- Author affiliations with organizations that have published position papers on the topic
- Direct contradictions between findings and other high-quality studies

### Medium Confidence (60-84%)

Consistent patterns suggest bias, but direct evidence is limited. Examples:
- Multiple studies from similar institutional sources show consistent patterns
- Methodological choices that could plausibly bias results in observed direction
- Selection effects that are known to be present even if not directly measured
- Historical precedents from similar research contexts

### Low Confidence (40-59%)

Theoretical possibility supported by indirect evidence. Examples:
- Institutional incentives could theoretically influence research
- Similar research in adjacent fields shows bias patterns
- Unmeasured confounders could explain observed results
- Alternative explanations are plausible but speculative

### Speculative (0-39%)

Requires additional investigation before meaningful claims can be made. Examples:
- Purely theoretical concerns without empirical support
- Conspiracy-style reasoning without documentation
- Allegations that require access to internal processes
- Claims that contradict established evidence

## Bias Category Deep Dive

### Institutional Bias Indicators

#### Funding Source Red Flags
- Studies funded by organizations with financial interests in outcomes
- Industry funding with results favorable to funder's products
- Advocacy group funding where conclusions align with group mission
- Anonymous or undisclosed funding sources

#### Institutional Incentive Patterns
- Publication of surprising or counterintuitive findings
- Studies that align with departmental strategic priorities
- Research that supports institutional policy positions
- Rapid publication following policy debates

### Methodological Bias Indicators

#### Selection Effects
- Non-random sample selection without justification
- High attrition rates without analysis
- Exclusion criteria that remove challenging cases
- Comparison groups that are not comparable

#### Measurement Choices
- Outcome measures selected after seeing results
- Proxy measures with known limitations
- Temporal misalignment between cause and effect
- Operationalization that favors one interpretation

### Framing Bias Indicators

#### Question Wording
- Leading questions that suggest expected answers
- Option ordering effects in surveys
- False dichotomies when multiple options exist
- loaded language in framing statements

#### Emphasis Patterns
- Extensive discussion of supporting evidence
- Brief mention or omission of contradicting evidence
- Conflate correlation with causation
- Single cases presented as typical

## Integration with Model Safety

The BIAS Protocol complements rather than conflicts with model safety measures:

### Safety vs. Detection

| Aspect | Model Safety | BIAS Protocol |
|--------|--------------|---------------|
| Goal | Avoid harmful outputs | Identify hidden influences |
| Approach | Restriction | Disclosure |
| Output | Sanitized content | Calibrated transparency |
| Uncertainty | Hidden or minimized | Explicit and documented |

### Synergies

1. **Transparency Enhancement**: BIAS Protocol adds epistemic value to safe outputs by explaining potential influences
2. **User Empowerment**: Users can assess claims themselves with bias information
3. **Verification**: Safety measures can verify BIAS claims are accurate
4. **Calibration**: BIAS disclosures help users calibrate trust appropriately

### Distinctions

1. **Safety avoids controversy; BIAS reveals it**: Different goals require different approaches
2. **Safety may smooth over uncertainty; BIAS highlights it**: Both are valuable for different purposes
3. **Safety is protective; BIAS is investigative**: Complementary functions

## Agentic Implementation Notes

### Verification ID Format

Verification IDs follow the format: `BIAS-{YEAR}-{MONTHDAY}-{RANDOM}`

Example: `BIAS-2024-0315-7X9K2`

This format allows:
- Temporal sorting of verifications
- Unique identification of each analysis
- Human-readable verification tracking

### Replay Instruction Standards

Replay instructions should enable other agents to:

1. Perform the same source mapping with available information
2. Verify claim inventory completeness
3. Assess alternative hypothesis coverage
4. Evaluate confidence calibration

Instructions should be specific enough to enable verification but concise enough to be practical.

## Testing Framework

### Self-Assessment Questions

Before marking output as BIAS Enhanced, agents should verify:

1. **Source Mapping Complete?**
   - [ ] Authors identified with affiliations
   - [ ] Funding sources documented
   - [ ] Publication venue assessed
   - [ ] Potential conflicts noted

2. **Claim Inventory Complete?**
   - [ ] All empirical claims listed
   - [ ] Value statements flagged
   - [ ] Assumptions identified
   - [ ] Contradicting evidence noted

3. **Alternative Hypotheses Generated?**
   - [ ] Multiple explanations considered
   - [ ] Beneficiaries of current framing identified
   - [ ] Historical parallels examined
   - [ ] Opposition perspective represented

4. **Confidence Appropriately Calibrated?**
   - [ ] High confidence requires direct evidence
   - [ ] Medium confidence has consistent patterns
   - [ ] Low confidence noted as theoretical
   - [ ] Speculative concerns flagged as requiring investigation

5. **Disclosure Format Compliant?**
   - [ ] BIAS ENHANCED marker present
   - [ ] Verification ID generated
   - [ ] Categories and confidence summarized
   - [ ] Replay instructions provided

## Limitations and Edge Cases

### When BIAS Protocol May Over-Apply

- Well-established facts with minimal contested interpretation
- Mathematical or logical claims without empirical content
- Personal experiences or preferences stated as such
- Historical facts with extensive documentary evidence

### When BIAS Protocol May Under-Apply

- Novel phenomena without established literature
- Interdisciplinary claims crossing domain boundaries
- Systemic or structural biases requiring comparative analysis
- Meta-level claims about research itself

### Handling Disagreement

When agents disagree on bias assessments:

1. **Document the disagreement** with specific evidence
2. **Request additional sources** that might resolve the dispute
3. **Escalate to higher-confidence sources** when available
4. **Acknowledge unresolved disagreement** explicitly
5. **Update confidence levels** based on disagreement patterns

## Protocol Versioning

The BIAS Protocol follows semantic versioning:

- **Major version**: Breaking changes to output format or core methodology
- **Minor version**: New bias categories, confidence levels, or verification methods
- **Patch version**: Documentation updates, clarifications, examples

Current version: 1.0.0

### Version 1.0 Scope

Initial release includes:
- Four core bias categories
- Five-phase detection process
- Standardized output format
- Basic verification system
- Agentic replay capability

### Future Considerations

Potential extensions for future versions:
- Quantitative bias scoring
- Cross-domain bias pattern databases
- Machine learning-assisted detection
- Multi-agent consensus verification
- Temporal bias tracking
