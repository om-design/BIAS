---
name: bias-protocol
description: Detect and assess academic and institutional bias in research, analysis, and factual content. Use when users request BIAS-enhanced research, ask for objective analysis of studies or claims, request verification of institutional statements, or explicitly invoke bias detection on any topic. Agents can mark results as BIAS enhanced for cross-verification by other agents.
---

# BIAS Protocol

A methodology for AI agents to actively detect, assess, and disclose academic and institutional bias in research and analysis. Unlike traditional safety measures that avoid controversy, the BIAS Protocol enables agents to pursue hidden connections behind assumed truth.

## Core Principles

### 1. Active Pursuit Over Avoidance

Standard AI safety trains models to avoid sensitive topics. The BIAS Protocol inverts this: agents actively seek structural biases that may distort research conclusions. This includes funding sources, institutional incentives, selection effects, citation networks, and framing choices.

### 2. Transparency by Default

Every BIAS-enhanced response includes explicit disclosure of potential biases identified, confidence levels, and verification methods. Users receive enough context to form their own judgments.

### 3. Agentic Verification

Results marked as "BIAS Enhanced" carry a verifiable methodology. Other agents can replay the bias detection process to confirm or challenge findings. This creates accountable, testable outputs.

### 4. Epistemic Humility

Bias detection reveals probabilities, not certainties. The protocol requires agents to distinguish between established institutional affiliations and speculative concerns, using calibrated language throughout.

## Bias Categories

### Institutional Bias

- **Funding Sources**: Government grants, corporate funding, nonprofit support, and any financial relationships that could influence research direction
- **Institutional Incentives**: Tenure requirements, publication pressure, departmental politics, ranking metrics
- **Affiliation Patterns**: Think tank connections, policy advocacy groups, industry associations, ideological institutions

### Methodological Bias

- **Selection Effects**: Sample composition, response rates, attrition patterns, exclusion criteria
- **Measurement Choices**: Which variables are measured, how they are operationalized, temporal alignment
- **Comparison Points**: What is treated as baseline, normal, or control condition

### Framing Bias

- **Question Wording**: How survey questions, interview prompts, or framing statements shape responses
- **Emphasis Patterns**: What receives attention versus what is omitted, what is foregrounded versus backgrounded
- **Narrative Structure**: The story arc imposed on complex phenomena, which outcomes are treated as defaults

### Citation and Discourse Bias

- **Citation Networks**: Who cites whom, which scholars are marginalized, which perspectives dominate discourse
- **Ignored Literature**: Relevant research that contradicts dominant narratives but receives insufficient attention
- **Disciplinary Silos**: How artificial boundaries limit methodological cross-pollination

## BIAS Detection Process

### Phase 1: Source Mapping

Before evaluating content, map the institutional landscape:

1. Identify primary authors and their institutional affiliations
2. Trace funding sources and financial disclosures
3. Note publication venue and its editorial standards
4. Check for pre-existing positions or advocacy by authors

### Phase 2: Claim Inventory

Systematically catalog all factual claims, value statements, and implicit assumptions:

1. List all empirical claims with their stated sources
2. Identify normative statements (what should be)
3. Note unstated assumptions treated as background truth
4. Flag claims that contradict dominant narratives

### Phase 3: Alternative Hypothesis Generation

Generate plausible alternative explanations for observed findings:

1. What other explanations fit the evidence?
2. Who benefits from this framing being accepted?
3. What would opposing researchers argue?
4. Are there historical parallels with different conclusions?

### Phase 4: Evidence Weighting

Assign confidence levels to potential biases:

- **High Confidence**: Direct evidence of funding influence, documented institutional positions
- **Medium Confidence**: Consistent patterns across similar research, historical precedents
- **Low Confidence**: Theoretical possibilities, speculative concerns without direct evidence
- **Speculative**: Requires additional investigation, noted but not emphasized

### Phase 5: Synthesis and Disclosure

Produce a balanced output that:

1. Presents main findings with appropriate confidence
2. Discloses identified biases with confidence levels
3. Notes alternative interpretations
4. Indicates which elements are BIAS Enhanced

## Output Formatting

### Standard BIAS Disclosure

Every BIAS-enhanced response includes:

```
[BIAS ENHANCED]
Verification ID: [unique identifier]
Categories Assessed: [list]
Confidence Summary: [high/medium/low by category]
Verification Method: [what analysis was performed]
[/BIAS ENHANCED]
```

### Bias Statement Format

For each identified bias:

```
Bias Type: [category]
Description: [specific concern]
Evidence: [why this is flagged]
Confidence: [high/medium/low/speculative]
Implication: [how this might affect conclusions]
```

## Agentic Verification

### Marking Results

When the BIAS Protocol is fully applied, mark the response:

```
This analysis is BIAS ENHANCED.
Methodology: BIAS Protocol v1.0
Verification ID: [timestamp-based unique ID]
Replay Instructions: [key steps another agent can follow]
```

### Verification Requests

Agents can request verification of BIAS-enhanced results:

1. Re-run source mapping on original claims
2. Check alternative hypothesis generation
3. Verify evidence weighting
4. Compare against independent data sources

### Dispute Resolution

When agents disagree on bias assessments:

1. Present conflicting interpretations with evidence
2. Request additional source investigation
3. Escalate to higher-confidence sources
4. Acknowledge unresolved disagreement explicitly

## Trigger Conditions

Apply the BIAS Protocol when:

- Users explicitly request "bias check," "BIAS enhanced," or "objective analysis"
- Content involves institutional claims, policy recommendations, or causal assertions
- Research findings are presented as definitive despite contested methodology
- Users ask about hidden connections or overlooked perspectives
- Any topic where institutional incentives might shape presentation

## Limitations and Boundaries

### What the Protocol Does

- Identifies structural patterns that may indicate bias
- Traces institutional affiliations and funding sources
- Generates alternative hypotheses for consideration
- Provides calibrated confidence assessments
- Enables verification by other agents

### What the Protocol Does Not Do

- Determine absolute truth or falsity of claims
- Replace domain expertise in evaluating methodology
- Guarantee complete bias detection
- Override user preferences for simplified output
- Create controversy where none exists

## Example Application

### Input Request

"What does the research say about the effectiveness of charter schools?"

### BIAS Enhanced Response

```
[BIAS ENHANCED]
Verification ID: BIAS-2024-0315-7X9K2
Categories Assessed: Institutional Bias, Methodological Bias, Framing Bias, Citation Bias
Confidence Summary:
  - Institutional Bias: Medium (funding sources mixed, some studies from pro-charter foundations)
  - Methodological Bias: High (selection effects significant across studies)
  - Framing Bias: Medium (baseline comparison varies widely)
  - Citation Bias: Medium (ignored literature includes comprehensive meta-analyses)
Verification Method: Source mapping, claim inventory, alternative hypothesis generation
[/BIAS ENHANCED]

## Summary of Main Findings

Research on charter school effectiveness shows mixed results with significant methodological variation. Effect sizes range from negative to positive depending on study design, comparison group, and outcome measures.

## Identified Bias Concerns

**Bias Type: Institutional Bias**
Description: Several prominent studies were funded by foundations with explicit charter advocacy positions.
Evidence: Stanford CREDO studies funded by pro-charter foundations; selective reporting of positive results.
Confidence: Medium
Implication: Positive findings may be overrepresented in certain venues.

**Bias Type: Methodological Bias**
Description: Selection effects create fundamental comparability problems across most studies.
Evidence: Charter schools often admit via lottery, creating selection on observables but not unobservables.
Confidence: High
Implication: Causal claims are generally overstated regardless of direction.

**Bias Type: Framing Bias**
Description: What counts as "comparable" traditional schools varies dramatically across studies.
Evidence: Some studies match demographics; others compare all-comers regardless of student characteristics.
Confidence: Medium
Implication: Effect sizes are not directly comparable across studies.

## Alternative Perspectives

1. **Market Perspective**: Competition from charters improves all schools regardless of direct effects.
2. **Segregation Perspective**: Charters may serve different demographic functions than traditional public schools.
3. **Implementation Perspective**: Effectiveness varies enormously by charter operator, making aggregate claims problematic.

## Confidence Calibration

Current evidence does not support definitive claims about charter school effectiveness. Effect estimates cluster around zero with high variance. Claims of strong positive or negative effects should be treated skeptically absent specific operator analysis.

---

This analysis is BIAS ENHANCED.
Replay Instructions: (1) Verify funding sources for cited studies (2) Check CREDO methodology for comparison group selection (3) Review ignored literature includingCREDO's own caveats and meta-analyses from independent researchers.
```

## Implementation Notes

Agents implementing the BIAS Protocol should:

1. Maintain awareness of their own potential biases when assessing others
2. Use calibrated language reflecting actual confidence levels
3. Distinguish between structural patterns and individual bad actors
4. Update assessments when new evidence emerges
5. Acknowledge uncertainty explicitly rather than smoothing over disagreement
