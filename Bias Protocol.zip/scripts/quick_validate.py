#!/usr/bin/env python3
"""
Quick validation script for BIAS Protocol skill.
Validates frontmatter, structure, and naming conventions.
"""

import json
import os
import re
import sys
from pathlib import Path


def validate_frontmatter(skill_path: Path) -> tuple[bool, list[str]]:
    """Validate frontmatter format and required fields."""
    errors = []
    skill_md = skill_path / "SKILL.md"

    if not skill_md.exists():
        return False, ["SKILL.md not found"]

    content = skill_md.read_text(encoding="utf-8")

    # Check frontmatter starts at beginning
    if not content.startswith("---"):
        errors.append("SKILL.md must start with YAML frontmatter (---)")
        return False, errors

    # Extract frontmatter
    frontmatter_match = re.match(r"^---\n(.*?)\n---", content, re.DOTALL)
    if not frontmatter_match:
        errors.append("Could not parse YAML frontmatter")
        return False, errors

    try:
        import yaml
        frontmatter = yaml.safe_load(frontmatter_match.group(1))
    except Exception as e:
        errors.append(f"YAML parsing error: {e}")
        return False, errors

    # Check required fields
    required_fields = ["name", "description"]
    for field in required_fields:
        if field not in frontmatter:
            errors.append(f"Missing required frontmatter field: {field}")

    # Validate name format
    if "name" in frontmatter:
        name = frontmatter["name"]
        if not re.match(r"^[a-z0-9-]+$", name):
            errors.append(f"Name must be lowercase hyphen-case: '{name}'")
        if len(name) > 64:
            errors.append(f"Name exceeds 64 characters: {len(name)}")
        folder_name = skill_path.name
        if name != folder_name:
            errors.append(f"Name '{name}' must match folder name '{folder_name}'")

    # Validate description
    if "description" in frontmatter:
        desc = frontmatter["description"]
        if len(desc) < 20:
            errors.append("Description too short (minimum 20 characters)")
        # Check for trigger phrases
        trigger_phrases = ["use when", "use when user", "trigger"]
        has_trigger = any(phrase in desc.lower() for phrase in trigger_phrases)
        if not has_trigger:
            errors.append("Description should include trigger phrases (e.g., 'Use when...')")

    # Check no markdown before frontmatter
    lines_before_frontmatter = content.split("---")[0].strip()
    if lines_before_frontmatter:
        errors.append(f"Content found before frontmatter: {lines_before_frontmatter[:50]}")

    return len(errors) == 0, errors


def validate_meta(skill_path: Path) -> tuple[bool, list[str]]:
    """Validate _meta.json format."""
    errors = []
    meta_path = skill_path / "_meta.json"

    if not meta_path.exists():
        return False, ["_meta.json not found"]

    try:
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        return False, [f"Invalid JSON in _meta.json: {e}"]

    # Check required fields
    if "id" not in meta:
        errors.append("Missing required field: id")
    if "version" not in meta:
        errors.append("Missing required field: version")
    else:
        # Validate semver format
        version = meta["version"]
        if not re.match(r"^\d+\.\d+\.\d+$", version):
            errors.append(f"Version must be semver format: '{version}'")

    # Validate id is a number
    if "id" in meta:
        try:
            int(meta["id"])
        except (ValueError, TypeError):
            errors.append(f"ID must be a number: '{meta['id']}'")

    return len(errors) == 0, errors


def validate_structure(skill_path: Path) -> tuple[bool, list[str]]:
    """Validate directory structure."""
    errors = []

    # Check for dangerous path constructs
    dangerous_patterns = ["..", "~", "$", "${", "`", "|", ";", "&"]
    path_str = str(skill_path.resolve())
    for pattern in dangerous_patterns:
        if pattern in path_str:
            errors.append(f"Dangerous path pattern detected: {pattern}")

    # Check scripts directory if present
    scripts_dir = skill_path / "scripts"
    if scripts_dir.exists():
        for script in scripts_dir.glob("*.py"):
            if script.name.startswith("test_"):
                continue
            # Check script is not executable as main entry point without proper shebang
            content = script.read_text(encoding="utf-8", errors="ignore")
            if content and not content.startswith("#!"):
                pass  # Warning only, not error

    return len(errors) == 0, errors


def validate_naming(skill_path: Path) -> tuple[bool, list[str]]:
    """Validate all files use English/safe characters."""
    errors = []
    non_english_pattern = re.compile(r"[^\x00-\x7F]")

    for file_path in skill_path.rglob("*"):
        if file_path.is_file():
            rel_path = file_path.relative_to(skill_path)

            # Check filename
            filename = file_path.name
            if non_english_pattern.search(filename):
                errors.append(f"Non-ASCII filename: {rel_path}")

            # Check file content for non-ASCII (except in comments)
            try:
                content = file_path.read_text(encoding="utf-8")
                lines = content.split("\n")
                for i, line in enumerate(lines, 1):
                    # Skip comments
                    if line.strip().startswith("#") or line.strip().startswith("//"):
                        continue
                    # Skip frontmatter in SKILL.md
                    if "SKILL.md" in str(rel_path) and i <= 20:
                        continue
                    if non_english_pattern.search(line):
                        errors.append(f"Non-ASCII content in {rel_path} line {i}")
                        break
            except Exception:
                pass  # Binary files, skip

    return len(errors) == 0, errors


def main():
    """Run all validations."""
    if len(sys.argv) < 2:
        skill_path = Path("/workspace/temp-skills/bias-protocol")
    else:
        skill_path = Path(sys.argv[1])

    if not skill_path.exists():
        print(f"Error: Skill path not found: {skill_path}")
        sys.exit(1)

    all_errors = []

    # Run validations
    checks = [
        ("Frontmatter", validate_frontmatter),
        ("Metadata", validate_meta),
        ("Structure", validate_structure),
        ("Naming", validate_naming),
    ]

    for check_name, check_func in checks:
        passed, errors = check_func(skill_path)
        if errors:
            all_errors.extend([f"[{check_name}] {e}" for e in errors])
        status = "PASS" if passed else "FAIL"
        print(f"{status}: {check_name}")

    # Summary
    print()
    if all_errors:
        print("VALIDATION FAILED")
        for error in all_errors:
            print(f"  - {error}")
        sys.exit(1)
    else:
        print("VALIDATION PASSED")
        sys.exit(0)


if __name__ == "__main__":
    main()
