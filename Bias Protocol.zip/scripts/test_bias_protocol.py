#!/usr/bin/env python3
"""
Test script for BIAS Protocol skill validation and structure.
"""

import json
import sys
from pathlib import Path


def test_meta_json():
    """Test _meta.json exists and is valid."""
    meta_path = Path("/workspace/temp-skills/bias-protocol/_meta.json")
    assert meta_path.exists(), "_meta.json not found"

    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    assert "id" in meta, "Missing 'id' field"
    assert "version" in meta, "Missing 'version' field"
    assert isinstance(meta["id"], int), "id must be integer"
    assert meta["version"].count(".") == 2, "Version must be semver"

    print("PASS: _meta.json valid")


def test_skill_md_frontmatter():
    """Test SKILL.md has proper frontmatter."""
    skill_md = Path("/workspace/temp-skills/bias-protocol/SKILL.md")
    assert skill_md.exists(), "SKILL.md not found"

    content = skill_md.read_text(encoding="utf-8")
    assert content.startswith("---"), "SKILL.md must start with frontmatter"

    # Parse frontmatter
    import yaml
    frontmatter_match = content.split("---")[1]
    frontmatter = yaml.safe_load(frontmatter_match)

    assert "name" in frontmatter, "Missing 'name' field"
    assert "description" in frontmatter, "Missing 'description' field"
    assert frontmatter["name"] == "bias-protocol", "Name mismatch"
    assert len(frontmatter["description"]) > 20, "Description too short"

    print("PASS: SKILL.md frontmatter valid")


def test_core_sections():
    """Test SKILL.md contains required sections."""
    skill_md = Path("/workspace/temp-skills/bias-protocol/SKILL.md")
    content = skill_md.read_text(encoding="utf-8")

    required_sections = [
        "Core Principles",
        "Bias Categories",
        "BIAS Detection Process",
        "Output Formatting",
        "Agentic Verification",
        "Trigger Conditions",
    ]

    for section in required_sections:
        assert f"## {section}" in content or f"### {section}" in content, f"Missing section: {section}"

    print("PASS: All required sections present")


def test_bias_categories():
    """Test all bias categories are defined."""
    skill_md = Path("/workspace/temp-skills/bias-protocol/SKILL.md")
    content = skill_md.read_text(encoding="utf-8")

    categories = [
        "Institutional Bias",
        "Methodological Bias",
        "Framing Bias",
        "Citation and Discourse Bias",
    ]

    for category in categories:
        assert category in content, f"Missing bias category: {category}"

    print("PASS: All bias categories defined")


def test_verification_system():
    """Test verification system is documented."""
    skill_md = Path("/workspace/temp-skills/bias-protocol/SKILL.md")
    content = skill_md.read_text(encoding="utf-8")

    # Check for verification markers
    assert "[BIAS ENHANCED]" in content, "Missing BIAS ENHANCED marker"
    assert "Verification ID:" in content, "Missing Verification ID format"
    assert "Replay Instructions:" in content, "Missing Replay Instructions"

    print("PASS: Verification system documented")


def test_example_output():
    """Test example output format is provided."""
    skill_md = Path("/workspace/temp-skills/bias-protocol/SKILL.md")
    content = skill_md.read_text(encoding="utf-8")

    # Check for example
    assert "Example Application" in content or "example" in content.lower(), "Missing example"

    print("PASS: Example output present")


def main():
    tests = [
        test_meta_json,
        test_skill_md_frontmatter,
        test_core_sections,
        test_bias_categories,
        test_verification_system,
        test_example_output,
    ]

    print("Running BIAS Protocol skill tests...\n")

    passed = 0
    failed = 0

    for test in tests:
        try:
            test()
            passed += 1
        except AssertionError as e:
            print(f"FAIL: {test.__name__} - {e}")
            failed += 1
        except Exception as e:
            print(f"ERROR: {test.__name__} - {e}")
            failed += 1

    print(f"\n{'='*40}")
    print(f"Results: {passed} passed, {failed} failed")

    sys.exit(0 if failed == 0 else 1)


if __name__ == "__main__":
    main()
