#!/usr/bin/env python3
"""
Package skill for distribution.
Creates a .skill archive with all necessary files.
"""

import argparse
import json
import os
import shutil
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path


def collect_skill_files(skill_path: Path) -> list[Path]:
    """Collect all files to include in the skill package."""
    files = []
    skip_patterns = [
        "__pycache__",
        "*.pyc",
        ".git",
        ".DS_Store",
        "*.log",
        ".env",
        "node_modules",
    ]

    for file_path in skill_path.rglob("*"):
        if file_path.is_file():
            rel_path = file_path.relative_to(skill_path)

            # Check skip patterns
            skip = False
            for pattern in skip_patterns:
                if pattern in str(rel_path) or file_path.name == pattern:
                    skip = True
                    break

            # Skip hidden files at root
            if rel_path.parent == Path(".") and file_path.name.startswith("."):
                if file_path.name not in [".gitignore"]:
                    skip = True

            if not skip:
                files.append(file_path)

    return files


def validate_package_contents(files: list[Path], skill_path: Path) -> tuple[bool, list[str]]:
    """Validate package contents meet minimum requirements."""
    errors = []

    # Check for SKILL.md
    if not any(f.name == "SKILL.md" for f in files):
        errors.append("SKILL.md is required")

    # Check for _meta.json
    if not any(f.name == "_meta.json" for f in files):
        errors.append("_meta.json is required")

    # Validate meta contents
    meta_path = skill_path / "_meta.json"
    if meta_path.exists():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            if "id" not in meta:
                errors.append("_meta.json missing 'id' field")
            if "version" not in meta:
                errors.append("_meta.json missing 'version' field")
        except Exception as e:
            errors.append(f"_meta.json parsing error: {e}")

    return len(errors) == 0, errors


def create_skill_archive(skill_path: Path, output_path: Path) -> tuple[bool, str]:
    """Create the .skill archive file."""
    skill_name = skill_path.name
    manifest = {
        "name": skill_name,
        "created": datetime.now(timezone.utc).isoformat(),
        "files": [],
    }

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        archive_path = temp_path / f"{skill_name}.skill"

        with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as zf:
            # Add all skill files
            for file_path in collect_skill_files(skill_path):
                rel_path = file_path.relative_to(skill_path)
                zf.write(file_path, rel_path)
                manifest["files"].append(str(rel_path))

            # Add manifest inside the context manager
            manifest_path = temp_path / "manifest.json"
            manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
            zf.write(manifest_path, "manifest.json")
            manifest["files"].append("manifest.json")

        # Copy to output (after context manager closes)
        shutil.copy2(archive_path, output_path)

    return True, str(output_path)


def main():
    parser = argparse.ArgumentParser(description="Package skill for distribution")
    parser.add_argument(
        "skill_path",
        nargs="?",
        default="/workspace/temp-skills/bias-protocol",
        help="Path to skill directory",
    )
    parser.add_argument(
        "-o", "--output",
        help="Output path for .skill file",
    )

    args = parser.parse_args()
    skill_path = Path(args.skill_path)

    if not skill_path.exists():
        print(f"Error: Skill path not found: {skill_path}")
        sys.exit(1)

    # Determine output path
    if args.output:
        output_path = Path(args.output)
    else:
        output_path = skill_path.parent / f"{skill_path.name}.skill"

    print(f"Packaging skill: {skill_path}")
    print(f"Output: {output_path}")

    # Collect and validate files
    files = collect_skill_files(skill_path)
    print(f"Files to package: {len(files)}")
    for f in files:
        print(f"  - {f.relative_to(skill_path)}")

    valid, errors = validate_package_contents(files, skill_path)
    if not valid:
        print("\nPackage validation failed:")
        for error in errors:
            print(f"  - {error}")
        sys.exit(1)

    # Create archive
    success, result = create_skill_archive(skill_path, output_path)

    if success:
        print(f"\nSuccessfully created: {result}")
        print(f"Package size: {output_path.stat().st_size} bytes")
        sys.exit(0)
    else:
        print(f"\nPackage creation failed: {result}")
        sys.exit(1)


if __name__ == "__main__":
    main()
